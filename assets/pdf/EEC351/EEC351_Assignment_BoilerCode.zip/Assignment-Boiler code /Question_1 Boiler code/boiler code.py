import numpy as np
import matplotlib.pyplot as plt
from typing import Tuple, Dict
import warnings
warnings.filterwarnings('ignore')

##########################
# Any changes in the signature and return type of function will result in zero marks.
##########################


def compute_personal_parameters(uid: str) -> Tuple[int, int, float]:
    """Compute personal seed and parameters from university ID."""
 
    return (s, k, A)

def target_function(x: np.ndarray, A: float, k: int) -> np.ndarray:
    """Compute f(x) = σ((A + k)x) + A·ln(|x| + 1)·x + k·sin(πx)·x^2"""
    def sigmoid(z):
      
    
    return val

def generate_training_data(A: float, k: int, seed: int = None) -> Tuple[np.ndarray, np.ndarray]:
    """Generate training dataset with tie handling."""
   
    return (X, y)

def fit_affine_hypothesis(X: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """
    Fit affine hypothesis h(x) = ax + b using normal equations for least squares.
         
    Note:
        If the normal equations matrix is singular, uses least squares solution.
        If multiple minimizers exist, returns the one with smallest ℓ2 norm.
    """
   
    
    return (a_star, b_star)

def compute_expected_hypothesis(A: float, k: int, N: int = 100, seed: int = None) -> Tuple[float, float]:
    """Compute E[â_D], E[b̂_D] over N random datasets."""
    
    
    return (expected_a,expected_b)

def compute_bias_variance_decomposition(expected_a: float, expected_b: float, A: float, k: int, N: int = 100, seed: int = None) -> Dict[str, float]:
    """Compute bias-variance decomposition for E_out."""
  
    
    return {
        'expected_a': expected_a,
        'expected_b': expected_b,
        'bias_squared': bias_squared,
        'variance': variance,
        'total_error': total_error
    }

def plot_functions_with_variance(A: float, k: int, N: int = 100, seed: int = None) -> None:
    """Plot target function vs expected hypothesis with variance bands."""
    
def tester(uid,N):
    "This is for evaluation purpose. Making any changes in this will result in zero marks."
    uid = uid
    s, k, A = compute_personal_parameters(uid)
    N=N
    X, y = generate_training_data(A, k, seed=42)
    a, b = fit_affine_hypothesis(X, y)
    exp_a, exp_b = compute_expected_hypothesis(A, k, N, seed=42)
    results = compute_bias_variance_decomposition(exp_a, exp_b, A, k, N=100, seed=42)
    
    return(results)
if __name__ == "__main__":
    # Replace with your actual UID
    uid = "24911016"
    s, k, A = compute_personal_parameters(uid)
    print(f"Personal parameters: s={s}, k={k}, A={A}")
    N=100
    # Generate sample data and fit
    X, y = generate_training_data(A, k, seed=42)
    a, b = fit_affine_hypothesis(X, y)
    print(f"Sample hypothesis: h(x) = {a:.6f}x + {b:.6f}")
    
    # Compute expected hypothesis
    exp_a, exp_b = compute_expected_hypothesis(A, k, N, seed=42)
    print(f"Expected hypothesis: ḡ(x) = {exp_a:.6f}x + {exp_b:.6f}")
    
    # Bias-variance decomposition
    results = compute_bias_variance_decomposition(exp_a, exp_b, A, k, N=100, seed=42)
    print(f"Bias² = {results['bias_squared']:.8f}")
    print(f"Variance = {results['variance']:.8f}")
    print(f"Total Error = {results['total_error']:.8f}")
    
    # Generate visualization
    plot_functions_with_variance(A, k, N, seed=42)



