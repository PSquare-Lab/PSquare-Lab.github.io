def generate_dataset(uid: str):
    """
    Generate 10 batches (each with 3 points) from h(x) = 2 + A*x^2 + k*x^4.
    
    Args:
        uid (str): Unique identifier string (Team No / Student ID).
    
    Returns:
        dataset (list): List of 10 samples, each sample is a list of 3 (x, h(x)) tuples.
        params (dict): Dictionary containing computed parameters s, k, A.
    """
    # Step 1. Compute personal seed s
    s = sum(ord(ch) for ch in uid) % 10000
    
    # Step 2. Compute k and A
    k = 1 + (s % 7)  # k ∈ {1, …, 7}
    A = 1 + ((s // 7) % 3) * 0.5  # A ∈ {1, 1.5, 2}
    print(A)
    # Seed the RNG for reproducibility
    np.random.seed(s)
    
    # Define target function
    def h(x):
        return 2 + A * x**2 + k * x**4
    
    # Step 3. Generate 10 samples (batches of 3 points)
    dataset = []
    for _ in range(10):
        # Pick 3 random x values in [-2, 2]
        xs = np.random.uniform(-A, A, size=3)
        ys = [h(x) for x in xs]
        sample = list(zip(xs, ys))
        dataset.append(sample)
    
    return dataset, {"s": s, "k": k, "A": A}

def fit_quadratic(samples):
    """
    Given 10 samples (each with 3 (x,y) pairs), fit quadratic hypothesis
    h(x) = c0 + c1*x + c2*x^2 for each batch using least squares,
    then return the averaged coefficients.
    
    Args:
        samples (list): List of 10 batches, each batch is a list of 3 (x, y) pairs.
    
    Returns:
        (c0, c1, c2): Averaged coefficients across all 10 batches.
    """
    coeffs = []

    
    return c0, c1, c2


def hoeffding_sample_bound(epsilon=0.1, delta=0.05, B=1):
    """
    Computes minimum M using Hoeffding's inequality
    """

    return M_min


def hoeffding_ratio(epsilon=0.1, delta=0.05):

    return ratio, M_B1, M_B4

def tester(uid):
    uid = uid # Enter your uid
    dataset, params = generate_dataset(uid)
    c0, c1, c2 = fit_quadratic(dataset)
    
    M = hoeffding_sample_bound(0.1, 0.05, 1)   #Take epsilon=0.1, delta=0.05, B=1
    ratio, M1, M4 = hoeffding_ratio(0.1, 0.05) # epsilon=0.1, delta=0.05
    return c0,c1,c2,params

if __name__ == "__main__":
    uid = "student123" # Enter your uid
    dataset, params = generate_dataset(uid)
    c0, c1, c2 = fit_quadratic(dataset)
    print(f"Fitted coefficients:")
    print(f"  c0 (intercept): {c0:.4f}")
    print(f"  c1 (linear): {c1:.4f}")
    print(f"  c2 (quadratic): {c2:.4f}")
    print(f"Hypothesis: h(x) = {c0:.3f} + {c1:.3f}*x + {c2:.3f}*x^2")
    print(f"Minimum samples for B=1: {M:.3f}")
    M = hoeffding_sample_bound(0.1, 0.05, 1)   #Take epsilon=0.1, delta=0.05, B=1
    ratio, M1, M4 = hoeffding_ratio(0.1, 0.05) # epsilon=0.1, delta=0.05
    print(f"Hoeffding bounds:")
    print(f"  M(B=1): {M1:.3f}")
    print(f"  M(B=4): {M4:.3f}")
    print(f"  Ratio M(B=4)/M(B=1): {ratio:.3f}")

